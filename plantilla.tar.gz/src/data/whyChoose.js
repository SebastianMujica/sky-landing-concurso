import image from "@/images/resources/why-choose-1-1.jpg";

export const whyChooseOne = {
  image,
  tagline: "our benefits",
  title: "Why Choose Our Consultancy",
  text: "There are many variations of passages of but the majority have in some form, by injected humou or words which don't look even slightly believable of but the majority have suffered.",
  points: ["Integer et massa sit", "Integer et massa sit"],
  progresses: [
    {
      id: 1,
      title: "Consulting",
      count: 77,
    },
    {
      id: 2,
      title: "Finance",
      count: 60,
    },
  ],
};

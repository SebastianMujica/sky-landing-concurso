export const freeConsultation = {
  title: "Get your FREE \n business consultation",
  titleHighlight: "FREE",
  phone: "+1- ( 246 ) 333 - 0079",
  phoneHref: "12463330079",
  email: "needhelp@company.com",
};

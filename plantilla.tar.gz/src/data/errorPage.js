const errorPage = {
  title: "404",
  tagline: "Sorry we can't find that page!",
  text: "The page you are looking for was never existed.",
};

export default errorPage;

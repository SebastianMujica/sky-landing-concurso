export const counterOne = [
  {
    id: 1,
    icon: "icon-scrum",
    count: 8586,
    text: "Completed Cases",
  },
  {
    id: 2,
    icon: "icon-business-idea",
    count: 697,
    text: "Expert Consultant",
  },
  {
    id: 3,
    icon: "icon-recruit",
    count: 448,
    text: "Finance Advices",
  },
  {
    id: 4,
    icon: "icon-customer-review",
    count: 2887,
    text: "Happy Customers",
  },
];

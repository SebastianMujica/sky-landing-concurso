export const findSolution = {
  text: "Consulting &amp; Finance Services Built Specifically for your Business.",
  linkText: "Find Your Solution",
  href: "/about",
};

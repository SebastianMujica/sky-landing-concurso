export const trustedOne = {
  title: "Trusted Commercial Consulting & Finance Broker",
  items: [
    {
      id: 1,
      icon: "icon-briefcase",
      title: "Experienced",
      href: "/about",
      text: "Morbi nec finibus misd",
    },
    {
      id: 2,
      icon: "icon-bar-chart",
      title: "Convenience",
      href: "/about",
      text: "Morbi nec finibus misd",
    },
    {
      id: 3,
      icon: "icon-team-leader",
      title: "Professional",
      href: "/team",
      text: "Morbi nec finibus misd",
    },
  ],
};

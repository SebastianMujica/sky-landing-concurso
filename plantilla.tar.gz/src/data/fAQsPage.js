export const faqs = [
  {
    id: 1,
    title: "Interdum et malesuada fames ac ante ipsum",
    text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
  },
  {
    id: 2,
    title: "Maecenas condimentum sollicitudin ligula,",
    text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
  },
  {
    id: 3,
    title: "Duis rhoncus orci ut metus rhoncus",
    text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
  },
];

const fAQsPage = [faqs, faqs];

export default fAQsPage;

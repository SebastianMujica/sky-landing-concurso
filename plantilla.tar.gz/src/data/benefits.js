export const benefitsOne = {
  tagline: "Our benefits",
  title: "Modern Technologies For Grow Business",
  images: ["benefits-one-1.jpg", "benefits-one-2.jpg"],
  points: [
    {
      id: 1,
      icon: "icon-verification",
      title: "Financial",
      text: "There are many variations of passages of available but the majority have suffered alteration in some form, by injected humou or randomised.",
    },
    {
      id: 2,
      icon: "icon-help",
      title: "Consulting",
      text: "There are many variations of passages of available but the majority have suffered alteration in some form, by injected humou or randomised.",
    },
  ],
  rightText:
    "There are many variations of passages of available but the majority have suffered alteration in some form, by injected humou or randomised.",
  faqs: [
    {
      id: 1,
      title: "Interdum et malesuada fames ac ante ipsum",
      text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
    },
    {
      id: 2,
      title: "Maecenas condimentum sollicitudin ligula,",
      text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
    },
    {
      id: 3,
      title: "Duis rhoncus orci ut metus rhoncus",
      text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
    },
    {
      id: 4,
      title: "Duis rhoncus orci ut metus rhoncus",
      text: "Suspendisse finibus urna mauris, vitae consequat quam vel. Vestibulum leo ligula, vit commodo nisl Sed luctus venenatis pellentesque.",
    },
  ],
};

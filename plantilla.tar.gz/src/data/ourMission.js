import bg from "@/images/backgrounds/our-mission-bg.jpg";

export const ourMission = {
  bg,
  title: "Mission is to Protect \n your Businesses & \n Much More",
};

export const ourMissionTwo = {
  bg,
  title: "Mission is to Protect \n your Businesses & Much More",
  videoId: "Get7rqXYrbQ",
  videoText: "Watch video",
};

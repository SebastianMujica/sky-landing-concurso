export const howWeWorks = {
  tagline: "follow 3 steps",
  title: "How We Works",
  works: [
    {
      id: 1,
      icon: "icon-team",
      title: "Consult with Team",
      text: "Lorem ipsum dolor sit amet, consectetur notted adipisicing elit do eiusmod.",
    },
    {
      id: 2,
      icon: "icon-checklist",
      title: "Make a Plan",
      text: "Lorem ipsum dolor sit amet, consectetur notted adipisicing elit do eiusmod.",
    },
    {
      id: 3,
      icon: "icon-outsourcing",
      title: "Enjoy the Success",
      text: "Lorem ipsum dolor sit amet, consectetur notted adipisicing elit do eiusmod.",
    },
  ],
};

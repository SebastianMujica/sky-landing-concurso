export const ctaOne = {
  title: "We’re delivering the best \n customer experience",
  href: "/about",
};
